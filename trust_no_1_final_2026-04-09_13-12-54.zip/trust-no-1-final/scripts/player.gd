extends CharacterBody2D

# =============================================================
# PLAYER.GD — Jugador
# =============================================================
# Los nodos visuales (Body, Eye, LegLeft, LegRight) ya están
# creados en player.tscn. Este script solo los referencia
# con @onready y controla movimiento, física y animación.
# =============================================================

enum St { IDLE, RUN, JUMP, FALL, DEAD }
var st : St = St.IDLE

const SPD   := 140.0
const JMP   := -300.0
const GRAV  := 900.0
const MFALL := 550.0

var dead_t : float = 0.0
var anim_t : float = 0.0

# Referencias a nodos de la escena .tscn
# Los nombres deben coincidir exactamente con el árbol
@onready var _body : Polygon2D = $Body
@onready var _ll   : Polygon2D = $LegLeft
@onready var _lr   : Polygon2D = $LegRight

func _ready() -> void:
	add_to_group("player")

func _physics_process(delta: float) -> void:

	# ── Estado DEAD ────────────────────────────────────────────
	if st == St.DEAD:
		dead_t -= delta
		_body.color.a = maxf(0.0, dead_t / 1.2)
		if dead_t <= 0.0:
			GM.restart()
		return

	# ── Gravedad ───────────────────────────────────────────────
	if not is_on_floor():
		velocity.y = minf(velocity.y + GRAV * delta, MFALL)
	else:
		velocity.y = 0.0

	# ── Input horizontal ───────────────────────────────────────
	var dir := Input.get_axis("move_left", "move_right")
	velocity.x = dir * SPD

	# ── Salto ──────────────────────────────────────────────────
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JMP

	move_and_slide()

	# ── FSM ────────────────────────────────────────────────────
	if is_on_floor():
		st = St.RUN if absf(velocity.x) > 4.0 else St.IDLE
	else:
		st = St.JUMP if velocity.y < 0.0 else St.FALL

	_animate(delta)

	if global_position.y > 400.0:
		die()

func _animate(delta: float) -> void:
	anim_t += delta

	if st == St.RUN:
		_ll.position.y =  sin(anim_t * 18.0) * 2.5
		_lr.position.y = -sin(anim_t * 18.0) * 2.5
	else:
		_ll.position.y = 0.0
		_lr.position.y = 0.0

	match st:
		St.IDLE: _body.color = Color("#4a9fd4")
		St.RUN:  _body.color = Color("#5ab0e4")
		St.JUMP: _body.color = Color("#6bc0f0")
		St.FALL: _body.color = Color("#3a8fc4")

func die() -> void:
	if st == St.DEAD:
		return
	st     = St.DEAD
	dead_t = 1.2
	velocity = Vector2.ZERO
	_body.color = Color("#e24b4a")
	GM.on_death()
