extends Node2D

# =============================================================
# MENU.GD — Menú principal
# =============================================================
# La UI (fondo, título, botones) está en menu.tscn.
# Este script solo resetea el estado del juego al entrar
# y responde a las señales de los botones.
#
# Señales que deben estar conectadas en el editor:
#   BtnPlay → pressed → Menu → _on_play
#   BtnQuit → pressed → Menu → _on_quit
# =============================================================

func _ready() -> void:
	# Resetear estado al volver al menú
	GM.state  = GM.St.MENU
	GM.deaths = 0
	GM.level  = 1
	Engine.time_scale = 1.0

func _on_play() -> void:
	GM.start()

func _on_quit() -> void:
	get_tree().quit()
