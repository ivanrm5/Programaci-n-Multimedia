extends Node2D

# =============================================================
# FALLING_FLOOR.GD — Trampa: suelo que cae
# =============================================================
# Nodos que deben existir en ff.tscn con estos nombres:
#   Platform    (StaticBody2D)
#   Platform/ColorRect
#   TriggerZone (Area2D)
#
# La señal body_entered de TriggerZone se conecta aquí
# en _ready() — no hace falta conectarla en el editor.
# =============================================================

@export var delay : float = 0.5

enum S { IDLE, SHAKE, FALL, GONE }
var _s  : S     = S.IDLE
var _t  : float = 0.0
var _vy : float = 0.0
var _oy : float = 0.0

# Nodos creados en la escena .tscn
@onready var _platform : StaticBody2D = $Platform
@onready var _vis      : ColorRect    = $Platform/ColorRect
@onready var _zone     : Area2D       = $TriggerZone

func _ready() -> void:
	_oy = _platform.position.y
	_zone.body_entered.connect(_on_enter)

func _on_enter(body: Node) -> void:
	if body.is_in_group("player") and _s == S.IDLE:
		_s = S.SHAKE
		_t = delay

func _physics_process(delta: float) -> void:
	match _s:

		S.SHAKE:
			_t -= delta
			_platform.position.x = sin(_t * 55.0) * 2.0
			_vis.color = Color("#aa3a1a")
			if _t <= 0.0:
				_s  = S.FALL
				_vy = 30.0
				_platform.position.x = 0.0

		S.FALL:
			_vy += 550.0 * delta
			_platform.position.y += _vy * delta
			if _platform.global_position.y > 420.0:
				_s = S.GONE
				_platform.visible = false
				get_tree().create_timer(3.0).timeout.connect(
					_reset, CONNECT_ONE_SHOT
				)

func _reset() -> void:
	if not is_inside_tree():
		return
	_s = S.IDLE
	_vy = 0.0
	_platform.position.y = _oy
	_platform.position.x = 0.0
	_platform.visible    = true
	_vis.color           = Color("#6b4423")
