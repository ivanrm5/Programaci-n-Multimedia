extends Node2D

# =============================================================
# SPIKE.GD — Trampa: pico que cae del techo
# =============================================================
# Nodos que deben existir en spike.tscn:
#   Body        (StaticBody2D)
#   TriggerZone (Area2D)
# =============================================================

@export var delay : float = 0.35

enum S { IDLE, WAIT, FALL, GONE }
var _s  : S     = S.IDLE
var _t  : float = 0.0
var _vy : float = 0.0

@onready var _body : StaticBody2D = $Body
@onready var _zone : Area2D       = $TriggerZone

func _ready() -> void:
	_zone.body_entered.connect(_on_enter)

func _on_enter(body: Node) -> void:
	if body.is_in_group("player") and _s == S.IDLE:
		_s = S.WAIT
		_t = delay

func _physics_process(delta: float) -> void:
	match _s:

		S.WAIT:
			_t -= delta
			if _t <= 0.0:
				_s  = S.FALL
				_vy = 20.0

		S.FALL:
			_vy += 700.0 * delta
			_body.position.y += _vy * delta
			if _body.global_position.y > 420.0:
				_s = S.GONE
				_body.visible = false
				get_tree().create_timer(4.0).timeout.connect(
					_reset, CONNECT_ONE_SHOT
				)

func _reset() -> void:
	if not is_inside_tree():
		return
	_s = S.IDLE
	_vy = 0.0
	_body.position.y = 0.0
	_body.visible    = true
