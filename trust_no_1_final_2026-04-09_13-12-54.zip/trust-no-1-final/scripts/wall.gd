extends Node2D

# =============================================================
# WALL.GD — Trampa: pared que aplasta
# =============================================================
# Nodos que deben existir en wall.tscn:
#   Body        (StaticBody2D)
#   TriggerZone (Area2D)
# =============================================================

@export var spd  : float = 160.0
@export var dist : float = 150.0

enum S { IDLE, WAIT, MOVE, GONE }
var _s     : S     = S.IDLE
var _t     : float = 0.0
var _moved : float = 0.0

@onready var _body : StaticBody2D = $Body
@onready var _zone : Area2D       = $TriggerZone

func _ready() -> void:
	_zone.body_entered.connect(_on_enter)

func _on_enter(body: Node) -> void:
	if body.is_in_group("player") and _s == S.IDLE:
		_s = S.WAIT
		_t = 0.25

func _physics_process(delta: float) -> void:
	match _s:

		S.WAIT:
			_t -= delta
			if _t <= 0.0:
				_s = S.MOVE

		S.MOVE:
			var step := spd * delta
			_body.position.x -= step
			_moved += step
			if _moved >= dist:
				_s = S.GONE
				get_tree().create_timer(3.5).timeout.connect(
					_reset, CONNECT_ONE_SHOT
				)

func _reset() -> void:
	if not is_inside_tree():
		return
	_s     = S.IDLE
	_moved = 0.0
	_body.position.x = 0.0
