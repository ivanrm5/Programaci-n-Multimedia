extends "res://scripts/level_base.gd"

# =============================================================
# LEVEL1.GD — Nivel 1
# =============================================================
# Toda la geometría, trampas y HUD están en level_1.tscn.
# Este script solo hereda level_base.gd para tener la lógica
# de puerta, pausa y HUD sin repetir código.
#
# Si en el futuro quieres añadir lógica específica del nivel 1
# (música concreta, evento especial, etc.) se hace aquí.
# =============================================================

func _ready() -> void:
	super._ready()
