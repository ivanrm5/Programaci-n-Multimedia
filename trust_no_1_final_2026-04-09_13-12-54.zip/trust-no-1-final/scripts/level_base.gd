extends Node2D

# =============================================================
# LEVEL_BASE.GD — Base compartida por Level1 y Level2
# =============================================================
# Antes este script construía el HUD, la puerta y la geometría
# por código. Ahora todo eso está en la escena .tscn.
# Este script solo:
#   1. Referencia los nodos que necesita actualizar (HUD, puerta)
#   2. Conecta la señal de la puerta en _ready()
#   3. Actualiza el contador de muertes cada frame
#   4. Anima el parpadeo de la puerta
#   5. Gestiona la pausa
#
# Nodos que DEBEN existir en la escena con estos nombres:
#   Goal              (Area2D)
#   Goal/Glow         (ColorRect) — el interior que parpadea
#   HUD               (CanvasLayer)
#   HUD/DeathLabel    (Label)
#   HUD/PausePanel    (Control)
# =============================================================

@onready var _goal      : Area2D  = $Goal
@onready var _glow      : ColorRect = $Goal/Glow
@onready var _death_lbl : Label   = $HUD/DeathLabel
@onready var _pause_pan : Control = $HUD/PausePanel

var _pulse_t : float = 0.0

func _ready() -> void:
	# Conectar la señal de la puerta de salida
	_goal.body_entered.connect(_on_goal)

	# Actualizar el HUD con el valor actual de muertes
	_death_lbl.text = "Muertes: %d" % GM.deaths

	# Asegurarse de que la pausa empieza oculta
	_pause_pan.visible = false

func _process(delta: float) -> void:
	# Actualizar contador de muertes cada frame
	_death_lbl.text = "Muertes: %d" % GM.deaths

	# Parpadeo de la puerta con sin()
	_pulse_t += delta
	_glow.color.a = 0.12 + abs(sin(_pulse_t * 2.5)) * 0.28

func _on_goal(body: Node) -> void:
	if not body.is_in_group("player"):
		return
	await get_tree().create_timer(0.4).timeout
	GM.next()

# _unhandled_key_input en lugar de _input para evitar el error
# "is_action_just_pressed en InputEventMouseMotion" de Godot 4.5
func _unhandled_key_input(ev: InputEvent) -> void:
	if ev.is_action_pressed("ui_pause"):
		GM.toggle_pause()
		_pause_pan.visible = (GM.state == GM.St.PAUSED)

# Callbacks conectados a los botones del PausePanel en el editor
func _on_resume_pressed() -> void:
	GM.toggle_pause()
	_pause_pan.visible = false

func _on_restart_pressed() -> void:
	_pause_pan.visible = false
	GM.restart()

func _on_menu_pressed() -> void:
	GM.menu()
