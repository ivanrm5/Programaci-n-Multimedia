extends "res://scripts/level_base.gd"

# =============================================================
# LEVEL2.GD — Nivel 2
# =============================================================
# Igual que level1.gd — toda la geometría está en level_2.tscn.
# =============================================================

func _ready() -> void:
	super._ready()
