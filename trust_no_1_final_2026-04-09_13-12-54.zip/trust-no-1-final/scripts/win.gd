extends Node2D

# =============================================================
# WIN.GD — Pantalla de victoria
# =============================================================
# La UI está en win.tscn.
# Este script solo rellena el label de muertes en _ready()
# y responde a los botones.
#
# Señales que deben estar conectadas en el editor:
#   BtnAgain → pressed → Win → _on_again
#   BtnMenu  → pressed → Win → _on_menu
#
# El nodo T3 (Label) debe llamarse exactamente "T3" y estar
# en la ruta HUD/Root/Center/T3 dentro de win.tscn
# =============================================================

@onready var _t3 : Label = $HUD/Root/Center/T3

func _ready() -> void:
	_t3.text = "Muertes totales: %d" % GM.deaths

func _on_again() -> void:
	GM.start()

func _on_menu() -> void:
	GM.menu()
