extends Node

# =============================================================
# GM.GD — GameManager (Singleton / Autoload)
# =============================================================
# Este nodo existe durante toda la vida del juego.
# Godot lo registra en project.godot como autoload bajo el
# nombre "GM", por lo que cualquier script puede llamar a
# GM.deaths, GM.start(), etc. sin importarlo.
#
# Responsabilidades:
#   - Guardar el estado global del juego (MENU, PLAYING…)
#   - Contar las muertes del jugador
#   - Cambiar de escena (niveles, menú, victoria)
#   - Controlar la pausa (Engine.time_scale)
# =============================================================


# -------------------------------------------------------------
# ESTADOS DEL JUEGO
# -------------------------------------------------------------
# Enum = lista de constantes con nombre.
# Solo puede haber un estado activo a la vez.
enum St {
	MENU,     # el jugador está en el menú principal
	PLAYING,  # partida activa
	PAUSED,   # juego pausado (menú de pausa visible)
	DEAD,     # jugador ha muerto, esperando reinicio
	WIN       # ha completado todos los niveles
}

# Estado actual — empieza en MENU al abrir el juego
var state  : St  = St.MENU

# Número del nivel activo (1 o 2)
var level  : int = 1

# Contador total de muertes en la sesión actual
var deaths : int = 0


# -------------------------------------------------------------
# start() — Inicia una partida nueva desde el nivel 1
# -------------------------------------------------------------
func start() -> void:
	deaths = 0        # resetear muertes
	go_level(1)


# -------------------------------------------------------------
# go_level(n) — Carga el nivel n
# -------------------------------------------------------------
func go_level(n: int) -> void:
	level  = n
	state  = St.PLAYING
	Engine.time_scale = 1.0   # por si venimos de pausa
	# change_scene_to_file carga la escena y destruye la actual
	get_tree().change_scene_to_file("res://scenes/level_%d.tscn" % n)


# -------------------------------------------------------------
# restart() — Recarga el nivel actual (tras morir)
# -------------------------------------------------------------
func restart() -> void:
	Engine.time_scale = 1.0
	state = St.PLAYING
	get_tree().change_scene_to_file("res://scenes/level_%d.tscn" % level)


# -------------------------------------------------------------
# on_death() — El jugador ha muerto
# -------------------------------------------------------------
# Lo llama player.gd cuando detecta una muerte.
# La guarda "if state == St.DEAD" evita doble conteo.
func on_death() -> void:
	if state == St.DEAD:
		return
	state = St.DEAD
	deaths += 1


# -------------------------------------------------------------
# next() — Pasa al siguiente nivel o a la pantalla de victoria
# -------------------------------------------------------------
func next() -> void:
	if level < 2:
		go_level(level + 1)
	else:
		state = St.WIN
		get_tree().change_scene_to_file("res://scenes/win.tscn")


# -------------------------------------------------------------
# menu() — Vuelve al menú principal
# -------------------------------------------------------------
func menu() -> void:
	deaths = 0
	level  = 1
	state  = St.MENU
	Engine.time_scale = 1.0
	get_tree().change_scene_to_file("res://scenes/menu.tscn")


# -------------------------------------------------------------
# toggle_pause() — Activa o desactiva la pausa
# -------------------------------------------------------------
# Engine.time_scale = 0 congela todos los _process y
# _physics_process del juego excepto los marcados como ALWAYS.
func toggle_pause() -> void:
	if state == St.PLAYING:
		state = St.PAUSED
		Engine.time_scale = 0.0
	elif state == St.PAUSED:
		state = St.PLAYING
		Engine.time_scale = 1.0
