extends Node

# ─────────────────────────────────────────
#  AUDIOMANAGER — Singleton global
#  Gestiona música de fondo y efectos de sonido
#  NOTA: Los archivos de audio van en res://assets/audio/
#  Formatos soportados: .ogg (música), .wav (sfx)
# ─────────────────────────────────────────

@onready var music_player : AudioStreamPlayer = $MusicPlayer
@onready var sfx_player   : AudioStreamPlayer = $SFXPlayer

# Volúmenes por defecto (en dB)
const MUSIC_VOLUME_DB : float = -8.0
const SFX_VOLUME_DB   : float =  0.0

# Rutas de los archivos de audio
# ⚠ Sustituye por tus propios archivos .ogg / .wav
var _music_paths : Dictionary = {
	"menu"     : "res://assets/audio/music_menu.ogg",
	"gameplay" : "res://assets/audio/music_gameplay.ogg",
	"gameover" : "res://assets/audio/music_gameover.ogg",
	"win"      : "res://assets/audio/music_win.ogg",
}

var _sfx_paths : Dictionary = {
	"jump"   : "res://assets/audio/sfx_jump.wav",
	"death"  : "res://assets/audio/sfx_death.wav",
	"trap"   : "res://assets/audio/sfx_trap.wav",
	"goal"   : "res://assets/audio/sfx_goal.wav",
	"land"   : "res://assets/audio/sfx_land.wav",
}

var _current_track : String = ""

func _ready() -> void:
	music_player.volume_db = MUSIC_VOLUME_DB
	sfx_player.volume_db   = SFX_VOLUME_DB

# ── Reproducir música (evita reiniciar si ya suena) ──
func play_music(track_name: String) -> void:
	if track_name == _current_track and music_player.playing:
		return
	if not _music_paths.has(track_name):
		push_warning("AudioManager: track '%s' no encontrado" % track_name)
		return
	var path : String = _music_paths[track_name]
	if not ResourceLoader.exists(path):
		# Si el archivo no existe aún, lo ignoramos sin crash
		push_warning("AudioManager: archivo no encontrado → %s" % path)
		return
	music_player.stream    = load(path)
	music_player.play()
	_current_track         = track_name

# ── Reproducir efecto de sonido ───────────
func play_sfx(sfx_name: String) -> void:
	if not _sfx_paths.has(sfx_name):
		return
	var path : String = _sfx_paths[sfx_name]
	if not ResourceLoader.exists(path):
		return
	sfx_player.stream = load(path)
	sfx_player.play()

# ── Parar música ──────────────────────────
func stop_music() -> void:
	music_player.stop()
	_current_track = ""

# ── Ajustar volumen música (0.0 - 1.0) ───
func set_music_volume(value: float) -> void:
	music_player.volume_db = linear_to_db(clampf(value, 0.0, 1.0))

# ── Ajustar volumen sfx (0.0 - 1.0) ──────
func set_sfx_volume(value: float) -> void:
	sfx_player.volume_db = linear_to_db(clampf(value, 0.0, 1.0))
