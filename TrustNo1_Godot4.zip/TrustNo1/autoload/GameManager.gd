extends Node

# ─────────────────────────────────────────
#  GAMEMANAGER — Singleton global
#  Gestiona el estado del juego, niveles y muertes
# ─────────────────────────────────────────

signal level_completed
signal player_died
signal state_changed(new_state)

enum GameState { MENU, PLAYING, PAUSED, GAME_OVER, WIN }

var current_state : GameState = GameState.MENU
var current_level : int       = 1
var total_levels  : int       = 2
var deaths        : int       = 0

# ── Cambiar estado global ──────────────────
func change_state(new_state: GameState) -> void:
	current_state = new_state
	emit_signal("state_changed", new_state)

	match new_state:
		GameState.PLAYING:
			Engine.time_scale = 1.0
		GameState.PAUSED:
			Engine.time_scale = 0.0
		GameState.GAME_OVER:
			deaths += 1
			Engine.time_scale = 1.0
			emit_signal("player_died")
		GameState.WIN:
			Engine.time_scale = 1.0

# ── Cargar nivel por número ────────────────
func load_level(level_number: int) -> void:
	current_level = level_number
	change_state(GameState.PLAYING)
	get_tree().change_scene_to_file(
		"res://scenes/level_%d.tscn" % level_number
	)

# ── Reiniciar el nivel actual ──────────────
func restart_level() -> void:
	Engine.time_scale = 1.0
	load_level(current_level)

# ── Ir al siguiente nivel ──────────────────
func next_level() -> void:
	emit_signal("level_completed")
	if current_level < total_levels:
		load_level(current_level + 1)
	else:
		change_state(GameState.WIN)
		get_tree().change_scene_to_file("res://scenes/win_screen.tscn")

# ── Ir al menú principal ───────────────────
func go_to_menu() -> void:
	deaths        = 0
	current_level = 1
	Engine.time_scale = 1.0
	change_state(GameState.MENU)
	get_tree().change_scene_to_file("res://scenes/menu.tscn")

# ── Reset completo ─────────────────────────
func reset() -> void:
	deaths        = 0
	current_level = 1
	current_state = GameState.MENU
	Engine.time_scale = 1.0
