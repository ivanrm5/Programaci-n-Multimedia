# TrustNo1 — Proyecto Godot 4

Juego de plataformas 2D estilo Level Devil para la práctica final de
Programación Multimedia y Dispositivos Móviles (2º DAM).

---

## Requisitos

- Godot Engine 4.2 o superior (descarga en https://godotengine.org)
- NO requiere ningún plugin externo

---

## Cómo importar el proyecto

1. Abre Godot Engine
2. En el Gestor de proyectos pulsa **Importar**
3. Navega hasta la carpeta `TrustNo1/` y selecciona `project.godot`
4. Pulsa **Importar y editar**
5. El proyecto abrirá directamente con la escena del menú

---

## Estructura de archivos

```
TrustNo1/
├── project.godot          ← Configuración del proyecto
├── assets/
│   ├── icon.svg           ← Icono del juego
│   ├── sprites/           ← Aquí van tus sprites (.png)
│   └── audio/             ← Aquí van tus archivos de audio
│       ├── music_menu.ogg
│       ├── music_gameplay.ogg
│       ├── music_gameover.ogg
│       ├── music_win.ogg
│       ├── sfx_jump.wav
│       ├── sfx_death.wav
│       ├── sfx_trap.wav
│       ├── sfx_goal.wav
│       └── sfx_land.wav
├── autoload/
│   ├── GameManager.gd     ← Singleton: estados, niveles, muertes
│   └── AudioManager.gd    ← Singleton: música y sfx
├── scenes/
│   ├── menu.tscn           ← Menú principal
│   ├── level_1.tscn        ← Nivel 1
│   ├── level_2.tscn        ← Nivel 2
│   ├── win_screen.tscn     ← Pantalla de victoria
│   ├── player.tscn         ← Escena reutilizable del jugador
│   ├── falling_floor.tscn  ← Trampa: suelo que cae
│   ├── moving_wall.tscn    ← Trampa: pared que aplasta
│   └── falling_spike.tscn  ← Trampa: pico que cae del techo
└── scripts/
    ├── player.gd           ← FSM del jugador
    ├── trap_base.gd        ← Clase base de trampas
    ├── falling_floor.gd    ← Lógica suelo que cae
    ├── moving_wall.gd      ← Lógica pared móvil
    ├── falling_spike.gd    ← Lógica pico del techo
    ├── level_base.gd       ← Script compartido por los niveles
    ├── goal.gd             ← Puerta de salida
    ├── menu.gd             ← Menú principal
    └── win_screen.gd       ← Pantalla de victoria
```

---

## Pasos después de importar

### 1. Añadir sprites al jugador
- Abre `scenes/player.tscn`
- Selecciona `AnimatedSprite2D`
- En el Inspector → SpriteFrames → Editar
- Añade frames para: `idle`, `run`, `jump`, `fall`, `death`
- Si no tienes sprites, descarga assets gratuitos en:
  - https://itch.io/game-assets/free/tag-2d
  - https://kenney.nl/assets

### 2. Diseñar los niveles con TileMap
- Abre `scenes/level_1.tscn`
- Selecciona el nodo `TileMapLayer`
- En Inspector → TileSet → Nuevo TileSet
- Importa tu spritesheet de tiles (o usa ColorRects de placeholder)
- Activa la pestaña `TileMap` en la parte inferior y pinta el nivel
- El nivel mínimo necesita: suelo, paredes laterales, plataformas

### 3. Ajustar posiciones de trampas
- En `level_1.tscn` y `level_2.tscn`, selecciona cada trampa
- Muévela en el viewport al lugar donde quieras que aparezca
- Puedes cambiar `trigger_delay` y `reset_time` en el Inspector

### 4. Añadir audio (opcional pero recomendado)
- Descarga efectos gratuitos en https://freesound.org
- Coloca los archivos en `assets/audio/` con los nombres exactos del README
- Si falta algún archivo, AudioManager lo ignora sin crashear

### 5. Ejecutar el juego
- Pulsa F5 o el botón ▶ en Godot
- La escena principal es `scenes/menu.tscn`

---

## Controles

| Tecla | Acción |
|-------|--------|
| A / ← | Mover izquierda |
| D / → | Mover derecha |
| W / ↑ / Espacio | Saltar |
| Esc | Pausa |

---

## Trampas incluidas

| Trampa | Descripción | Propiedades exportadas |
|--------|-------------|----------------------|
| FallingFloor | Suelo que vibra y cae al acercarse | `trigger_delay`, `fall_speed_start`, `reset_time` |
| MovingWall | Pared que se desplaza horizontalmente | `move_speed`, `move_distance`, `direction` |
| FallingSpike | Pico que cae del techo al pasar por debajo | `drop_speed`, `trigger_delay` |

---

## Cómo añadir una trampa nueva

1. Crea un nuevo script que extienda `trap_base.gd`:
```gdscript
extends "res://scripts/trap_base.gd"

func activate() -> void:
    # Tu lógica aquí
    pass
```
2. Crea una escena con raíz `Node2D`, añade `StaticBody2D`, `Area2D` (llamado TriggerZone) y `Timer` (llamado ActivationDelay)
3. Asigna tu script a la raíz
4. Instancia la escena en el nivel donde quieras

---

## Créditos
Proyecto desarrollado con Godot Engine 4 para la asignatura
Programación Multimedia y Dispositivos Móviles — 2º DAM.
