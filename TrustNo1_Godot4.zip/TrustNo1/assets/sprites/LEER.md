# Sprites del jugador y del nivel

## Jugador (player.tscn → AnimatedSprite2D)

Necesitas un spritesheet o imágenes individuales para:
- idle    → 2-4 frames, personaje parado
- run     → 4-8 frames, personaje corriendo
- jump    → 1-2 frames, en el aire subiendo
- fall    → 1-2 frames, en el aire bajando
- death   → 3-5 frames, animación de muerte

Tamaño recomendado por frame: 16x16 px o 32x32 px

## Tiles del nivel (TileMapLayer)

Necesitas una imagen con tiles para:
- Suelo (borde superior verde)
- Interior del suelo (relleno)
- Plataformas flotantes
- Fondo decorativo (opcional)

Tamaño de tile recomendado: 16x16 px

## Trampas

Cada trampa (FallingFloor, MovingWall, FallingSpike) tiene un
nodo Sprite2D donde puedes asignar su textura desde el Inspector.

## Recursos gratuitos recomendados
- https://kenney.nl/assets/platformer-art-complete-pack
- https://kenney.nl/assets/simplified-platformer-pack
- https://itch.io/game-assets/free/tag-platformer
- https://opengameart.org/content/platformer-art-complete-pack
