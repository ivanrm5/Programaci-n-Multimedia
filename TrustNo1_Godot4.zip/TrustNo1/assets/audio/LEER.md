# Archivos de audio

Coloca aquí tus archivos de sonido con exactamente estos nombres:

## Música (formato .ogg recomendado)
- music_menu.ogg       → Música del menú principal
- music_gameplay.ogg   → Música durante el juego
- music_gameover.ogg   → Música al morir
- music_win.ogg        → Música de victoria

## Efectos de sonido (formato .wav recomendado)
- sfx_jump.wav         → Salto del jugador
- sfx_death.wav        → Muerte del jugador
- sfx_trap.wav         → Activación de trampa
- sfx_goal.wav         → Llegar a la meta
- sfx_land.wav         → Aterrizar en el suelo

## Dónde conseguir audio gratuito
- https://freesound.org (requiere cuenta gratuita)
- https://kenney.nl/assets (packs completos gratuitos)
- https://itch.io/game-assets/free/tag-audio
- https://opengameart.org

## Nota
Si no tienes los archivos, el juego funciona igualmente.
AudioManager comprueba si existen antes de cargarlos.
