extends "res://scripts/trap_base.gd"

# ─────────────────────────────────────────
#  FALLING FLOOR — Suelo que cae
#  Al acercarse el jugador: vibra → cae → reaparece arriba
# ─────────────────────────────────────────

@export var fall_speed_start : float = 60.0
@export var fall_accel       : float = 300.0
@export var shake_intensity  : float = 2.0

@onready var body      : StaticBody2D   = $StaticBody2D
@onready var anim      : AnimationPlayer = $AnimationPlayer

var _falling      : bool  = false
var _fall_vel     : float = 0.0
var _origin_y     : float = 0.0

func _ready() -> void:
	super._ready()
	_origin_y = body.position.y

func _physics_process(delta: float) -> void:
	if _falling:
		_fall_vel += fall_accel * delta
		body.position.y += _fall_vel * delta

		# Si sale de pantalla, vuelve a posición original
		var screen_h : float = get_viewport_rect().size.y
		if body.global_position.y > screen_h + 50.0:
			_falling   = false
			_fall_vel  = 0.0
			body.position.y = _origin_y
			if auto_reset:
				await get_tree().create_timer(reset_time).timeout
				reset_trap()

# ── Vibración antes de caer ──────────────
func on_triggered() -> void:
	if anim.has_animation("shake"):
		anim.play("shake")

# ── Activación: empieza a caer ───────────
func activate() -> void:
	if anim.is_playing():
		anim.stop()
	body.position.x = 0.0   # por si la animación movió X
	_falling  = true
	_fall_vel = fall_speed_start

func on_reset() -> void:
	body.position.y = _origin_y
	body.position.x = 0.0
