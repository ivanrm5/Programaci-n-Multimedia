extends Control

# ─────────────────────────────────────────
#  WIN SCREEN — Pantalla de victoria
# ─────────────────────────────────────────

@onready var deaths_label : Label = $VBoxContainer/DeathsLabel

func _ready() -> void:
	AudioManager.play_music("win")
	deaths_label.text = "Muertes totales: %d" % GameManager.deaths

func _on_play_again_pressed() -> void:
	GameManager.reset()
	GameManager.load_level(1)

func _on_menu_pressed() -> void:
	GameManager.go_to_menu()
