extends Control

# ─────────────────────────────────────────
#  MENÚ PRINCIPAL
# ─────────────────────────────────────────

func _ready() -> void:
	GameManager.reset()
	AudioManager.play_music("menu")

func _on_play_pressed() -> void:
	GameManager.load_level(1)

func _on_quit_pressed() -> void:
	get_tree().quit()
