extends CharacterBody2D

# ─────────────────────────────────────────
#  PLAYER — CharacterBody2D
#  Máquina de estados: IDLE, RUNNING, JUMPING, FALLING, DEAD
# ─────────────────────────────────────────

enum State { IDLE, RUNNING, JUMPING, FALLING, DEAD }

# ── Constantes de movimiento ───────────────
const SPEED       : float = 120.0
const JUMP_FORCE  : float = -300.0
const GRAVITY     : float = 900.0
const MAX_FALL    : float = 500.0

# ── Estado interno ─────────────────────────
var state         : State = State.IDLE
var spawn_pos     : Vector2
var dead_timer    : float = 0.0
var DEAD_DURATION : float = 1.0   # segundos antes de reiniciar

# ── Referencias a nodos ────────────────────
@onready var sprite    : AnimatedSprite2D   = $AnimatedSprite2D
@onready var col       : CollisionShape2D   = $CollisionShape2D
@onready var ray_floor : RayCast2D          = $RayCast2D
@onready var snd       : AudioStreamPlayer2D = $AudioStreamPlayer2D

func _ready() -> void:
	spawn_pos = global_position
	add_to_group("player")

func _physics_process(delta: float) -> void:
	match state:
		State.DEAD:
			_process_dead(delta)
			return

	_apply_gravity(delta)
	_handle_input()
	_update_fsm()
	move_and_slide()
	_update_animation()
	_check_fall_death()

# ── Gravedad ───────────────────────────────
func _apply_gravity(delta: float) -> void:
	if not is_on_floor():
		velocity.y += GRAVITY * delta
		velocity.y  = minf(velocity.y, MAX_FALL)

# ── Input del jugador ──────────────────────
func _handle_input() -> void:
	var dir : float = Input.get_axis("move_left", "move_right")
	velocity.x = dir * SPEED

	if dir > 0.0:
		sprite.flip_h = false
	elif dir < 0.0:
		sprite.flip_h = true

	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_FORCE
		AudioManager.play_sfx("jump")

# ── FSM del jugador ────────────────────────
func _update_fsm() -> void:
	if is_on_floor():
		if absf(velocity.x) > 5.0:
			state = State.RUNNING
		else:
			state = State.IDLE
	else:
		if velocity.y < 0.0:
			state = State.JUMPING
		else:
			state = State.FALLING

# ── Animaciones ────────────────────────────
func _update_animation() -> void:
	match state:
		State.IDLE:
			sprite.play("idle")
		State.RUNNING:
			sprite.play("run")
		State.JUMPING:
			sprite.play("jump")
		State.FALLING:
			sprite.play("fall")

# ── Caer por debajo del nivel ──────────────
func _check_fall_death() -> void:
	var screen_h : float = get_viewport_rect().size.y
	if global_position.y > screen_h + 100.0:
		die()

# ── Muerte del jugador ─────────────────────
func die() -> void:
	if state == State.DEAD:
		return
	state      = State.DEAD
	dead_timer = DEAD_DURATION
	velocity   = Vector2.ZERO

	sprite.play("death")
	col.set_deferred("disabled", true)
	AudioManager.play_sfx("death")
	GameManager.change_state(GameManager.GameState.GAME_OVER)

func _process_dead(delta: float) -> void:
	dead_timer -= delta
	if dead_timer <= 0.0:
		GameManager.restart_level()

# ── Respawn manual (si lo necesitas) ──────
func respawn() -> void:
	global_position = spawn_pos
	velocity        = Vector2.ZERO
	state           = State.IDLE
	col.set_deferred("disabled", false)
	sprite.play("idle")
