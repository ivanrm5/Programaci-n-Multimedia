extends "res://scripts/trap_base.gd"

# ─────────────────────────────────────────
#  FALLING SPIKE — Pico que cae del techo
#  Detecta al jugador por debajo y cae verticalmente
# ─────────────────────────────────────────

@export var drop_speed : float = 400.0

@onready var spike_body : StaticBody2D = $StaticBody2D

var _dropping    : bool  = false
var _origin_y    : float

func _ready() -> void:
	super._ready()
	_origin_y = spike_body.position.y

func _physics_process(delta: float) -> void:
	if not _dropping:
		return

	spike_body.position.y += drop_speed * delta

	var screen_h : float = get_viewport_rect().size.y
	if spike_body.global_position.y > screen_h + 50.0:
		_dropping = false
		spike_body.position.y = _origin_y
		if auto_reset:
			await get_tree().create_timer(reset_time).timeout
			reset_trap()

func activate() -> void:
	_dropping = true

func on_reset() -> void:
	spike_body.position.y = _origin_y
