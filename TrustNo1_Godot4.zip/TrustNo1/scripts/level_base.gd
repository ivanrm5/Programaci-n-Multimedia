extends Node2D

# ─────────────────────────────────────────
#  LEVEL BASE — Script compartido por Level1 y Level2
#  Gestiona: meta, pausa, HUD, transición de nivel
# ─────────────────────────────────────────

# ── Referencias (deben existir en la escena del nivel) ──
@onready var goal        : Area2D      = $Goal
@onready var hud         : CanvasLayer = $HUD
@onready var pause_menu  : Control     = $HUD/PauseMenu
@onready var death_label : Label       = $HUD/DeathCounter
@onready var level_label : Label       = $HUD/LevelName
@onready var camera      : Camera2D    = $Camera2D

func _ready() -> void:
	# Conectar llegada a la meta
	goal.body_entered.connect(_on_goal_reached)

	# Conectar señal de muerte para actualizar HUD
	GameManager.player_died.connect(_on_player_died)

	# Inicializar HUD
	_update_hud()

	# Ocultar menú pausa
	pause_menu.visible = false

	# Música de gameplay
	AudioManager.play_music("gameplay")

func _update_hud() -> void:
	death_label.text  = "Muertes: %d" % GameManager.deaths
	level_label.text  = "Nivel %d" % GameManager.current_level

func _on_player_died() -> void:
	_update_hud()

# ── Llegó a la meta ────────────────────────
func _on_goal_reached(body: Node) -> void:
	if not body.is_in_group("player"):
		return
	AudioManager.play_sfx("goal")
	AudioManager.play_music("win")
	# Pequeña pausa antes de cambiar de nivel
	await get_tree().create_timer(0.6).timeout
	GameManager.next_level()

# ── Pausa ──────────────────────────────────
func _input(event: InputEvent) -> void:
	if event.is_action_just_pressed("pause"):
		_toggle_pause()

func _toggle_pause() -> void:
	var is_paused : bool = GameManager.current_state == GameManager.GameState.PAUSED
	if is_paused:
		GameManager.change_state(GameManager.GameState.PLAYING)
		pause_menu.visible = false
	else:
		GameManager.change_state(GameManager.GameState.PAUSED)
		pause_menu.visible = true

# ── Botones del menú pausa ─────────────────
func _on_resume_pressed() -> void:
	_toggle_pause()

func _on_restart_pressed() -> void:
	GameManager.change_state(GameManager.GameState.PLAYING)
	GameManager.restart_level()

func _on_menu_pressed() -> void:
	GameManager.go_to_menu()
