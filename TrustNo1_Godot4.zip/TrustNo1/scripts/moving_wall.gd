extends "res://scripts/trap_base.gd"

# ─────────────────────────────────────────
#  MOVING WALL — Pared que aplasta
#  Se desplaza horizontalmente hacia el jugador
# ─────────────────────────────────────────

@export var move_speed    : float = 180.0
@export var move_distance : float = 200.0
@export var direction     : Vector2 = Vector2.LEFT  # LEFT o RIGHT

@onready var wall_body : StaticBody2D = $StaticBody2D

var _moving      : bool    = false
var _origin_pos  : Vector2

func _ready() -> void:
	super._ready()
	_origin_pos = wall_body.position

func _physics_process(delta: float) -> void:
	if not _moving:
		return

	wall_body.position += direction * move_speed * delta

	var dist : float = wall_body.position.distance_to(_origin_pos)
	if dist >= move_distance:
		_moving = false
		if auto_reset:
			await get_tree().create_timer(reset_time).timeout
			reset_trap()

func activate() -> void:
	_moving = true

func on_reset() -> void:
	wall_body.position = _origin_pos
