extends Node2D

# ─────────────────────────────────────────
#  TRAP BASE — Clase base para todas las trampas
#  Hereda de esta clase con: extends "res://scripts/trap_base.gd"
#  FSM: IDLE → TRIGGERED → ACTIVE → (reset → IDLE)
# ─────────────────────────────────────────

enum TrapState { IDLE, TRIGGERED, ACTIVE, RESETTING }

var trap_state : TrapState = TrapState.IDLE

# ── Propiedades exportables (editables en Inspector) ─
@export var trigger_delay  : float = 0.5   # segundos antes de activarse
@export var reset_time     : float = 3.0   # segundos hasta que se reinicia
@export var auto_reset     : bool  = true  # ¿se resetea sola?

# ── Referencias (deben existir en la escena hija) ────
@onready var trigger_zone  : Area2D = $TriggerZone
@onready var timer         : Timer  = $ActivationDelay

func _ready() -> void:
	# Conectar señal del Area2D
	trigger_zone.body_entered.connect(_on_body_entered)

	# Configurar timer
	timer.wait_time  = trigger_delay
	timer.one_shot   = true
	timer.timeout.connect(_on_timer_timeout)

# ── Se llama cuando algo entra en el TriggerZone ────
func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player") and trap_state == TrapState.IDLE:
		_trigger()

# ── Marcar como activada y arrancar timer ───────────
func _trigger() -> void:
	trap_state = TrapState.TRIGGERED
	AudioManager.play_sfx("trap")
	on_triggered()   # hook para subclases (ej: animación de vibración)
	timer.start()

# ── Timer terminó → activar trampa ─────────────────
func _on_timer_timeout() -> void:
	trap_state = TrapState.ACTIVE
	activate()       # implementado en cada trampa hija

# ── Hooks para subclases ────────────────────────────
func on_triggered() -> void:
	pass  # override si necesitas lógica antes de activarse

func activate() -> void:
	pass  # override obligatorio en subclases

# ── Resetear trampa al estado inicial ───────────────
func reset_trap() -> void:
	trap_state = TrapState.IDLE
	on_reset()

func on_reset() -> void:
	pass  # override si necesitas restaurar posición/visual
