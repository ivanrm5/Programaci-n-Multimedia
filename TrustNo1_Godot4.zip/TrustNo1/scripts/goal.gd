extends Area2D

# ─────────────────────────────────────────
#  GOAL — Puerta de salida del nivel
#  Parpadea para que el jugador la identifique
# ─────────────────────────────────────────

@onready var sprite : Sprite2D         = $Sprite2D
@onready var anim   : AnimationPlayer  = $AnimationPlayer
@onready var light  : PointLight2D     = $PointLight2D  # opcional

var _time : float = 0.0

func _ready() -> void:
	if anim.has_animation("pulse"):
		anim.play("pulse")

func _process(delta: float) -> void:
	_time += delta
	# Efecto de parpadeo manual si no hay AnimationPlayer configurado
	if sprite and not anim.is_playing():
		var alpha := 0.7 + sin(_time * 3.0) * 0.3
		sprite.modulate.a = alpha
